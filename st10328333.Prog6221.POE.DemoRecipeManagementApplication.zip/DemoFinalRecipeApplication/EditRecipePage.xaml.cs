﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace DemoFinalRecipeApplication
{
    /// <summary>
    /// Interaction logic for EditRecipePage.xaml
    /// </summary>
    public partial class EditRecipePage : Page
    {
        private Recipes editedRecipe; // Variable to hold the edited recipe

        public EditRecipePage(Recipes recipe)
        {
            InitializeComponent();

            // Initialize the edited recipe with the recipe passed from the main window
            editedRecipe = recipe;

            // Set the data context of the page to the edited recipe
            DataContext = editedRecipe;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the previous page
            NavigationService.GoBack();
        }

        private void ClearIngredientFields()
        {
            // Clear all input fields related to ingredients
            IngredientNameTextBox.Clear();
            IngredientAmountTextBox.Clear();
            IngredientUnitTextBox.Clear();
            IngredientCaloriesTextBox.Clear();
            IngredientFoodGroupTextBox.Clear();
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            // Add a new ingredient to the edited recipe
            string name = IngredientNameTextBox.Text;

            if (double.TryParse(IngredientAmountTextBox.Text, out double amount) &&
                double.TryParse(IngredientCaloriesTextBox.Text, out double calories))
            {
                // Get values for unit and food group
                string unit = IngredientUnitTextBox.Text;
                string foodGroup = IngredientFoodGroupTextBox.Text;

                // Call method to add ingredient to the edited recipe object
                editedRecipe.AddIngredient(name, amount, unit, calories, foodGroup);

                // Clear input fields for ingredients
                IngredientNameTextBox.Clear();
                IngredientAmountTextBox.Clear();
                IngredientUnitTextBox.Clear();
                IngredientCaloriesTextBox.Clear();
                IngredientFoodGroupTextBox.Clear();

                // Update the list box displaying ingredients
                IngredientsListBox.ItemsSource = null; // Clear previous items source
                IngredientsListBox.ItemsSource = editedRecipe.Ingredients; // Set updated list of ingredients
            }
            else
            {
                // Display error message if input values are not valid
                MessageBox.Show("Please enter valid numeric values for Amount and Calories");
            }
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            // Add a new step to the edited recipe
            if (!string.IsNullOrWhiteSpace(StepTextBox.Text))
            {
                // Call method to add step to the edited recipe object
                editedRecipe.AddStep(StepTextBox.Text);

                // Refresh the list box displaying steps
                StepsListBox.Items.Refresh();

                // Clear input field for step description
                StepTextBox.Clear();
            }
            else
            {
                // Display error message if step description is empty
                MessageBox.Show("Please enter a step description.");
            }
        }
    }
}
