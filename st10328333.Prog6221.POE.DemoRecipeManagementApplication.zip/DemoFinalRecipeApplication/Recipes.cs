﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoFinalRecipeApplication
{
    /// <summary>
    /// Represents a recipe with its name, serving size, ingredients, and steps.
    /// Implements INotifyPropertyChanged for data binding.
    /// </summary>
    public class Recipes : INotifyPropertyChanged
    {
        private string _name;
        private int _servingSize;
        private List<Ingredient> _ingredients;
        private List<string> _steps;

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Constructor to initialize a new recipe with default values.
        /// </summary>
        public Recipes()
        {
            _name = string.Empty;
            _servingSize = 1;
            _steps = new List<string>();
            _ingredients = new List<Ingredient>();
        }

        /// <summary>
        /// Name of the recipe.
        /// </summary>
        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        /// <summary>
        /// Serving size of the recipe.
        /// </summary>
        public int ServingSize
        {
            get => _servingSize;
            set
            {
                if (_servingSize != value)
                {
                    _servingSize = value;
                    OnPropertyChanged(nameof(ServingSize));
                }
            }
        }

        /// <summary>
        /// List of ingredients in the recipe.
        /// </summary>
        public List<Ingredient> Ingredients
        {
            get => _ingredients;
            set
            {
                if (_ingredients != value)
                {
                    _ingredients = value;
                    OnPropertyChanged(nameof(Ingredients));
                }
            }
        }

        /// <summary>
        /// List of steps to prepare the recipe.
        /// </summary>
        public List<string> Steps
        {
            get => _steps;
            set
            {
                if (_steps != value)
                {
                    _steps = value;
                    OnPropertyChanged(nameof(Steps));
                }
            }
        }

        /// <summary>
        /// Calculates the total calories of all ingredients in the recipe.
        /// </summary>
        public double TotalCalories => _ingredients.Sum(ingredient => ingredient.Calories);

        /// <summary>
        /// Adds a new ingredient to the recipe.
        /// </summary>
        /// <param name="name">Name of the ingredient.</param>
        /// <param name="amount">Amount of the ingredient.</param>
        /// <param name="unit">Unit of measurement for the ingredient.</param>
        /// <param name="calories">Calories per unit of the ingredient.</param>
        /// <param name="foodGroup">Food group to which the ingredient belongs.</param>
        public void AddIngredient(string name, double amount, string unit, double calories, string foodGroup)
        {
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Ingredient name cannot be null or empty.", nameof(name));
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be greater than zero.");
            if (string.IsNullOrWhiteSpace(unit)) throw new ArgumentException("Units cannot be null or empty.", nameof(unit));
            if (calories < 0) throw new ArgumentOutOfRangeException(nameof(calories), "Calories cannot be negative or below zero");
            if (string.IsNullOrWhiteSpace(foodGroup)) throw new ArgumentException("Food group cannot be null or empty.", nameof(foodGroup));

            _ingredients.Add(new Ingredient { Name = name, Amount = amount, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            OnPropertyChanged(nameof(Ingredients));
            OnPropertyChanged(nameof(TotalCalories));
        }

        /// <summary>
        /// Adds a step to prepare the recipe.
        /// </summary>
        /// <param name="step">Description of the step.</param>
        public void AddStep(string step)
        {
            if (string.IsNullOrWhiteSpace(step)) throw new ArgumentException("Step cannot be null or empty.", nameof(step));

            _steps.Add(step);
            OnPropertyChanged(nameof(Steps));
        }

        /// <summary>
        /// Generates and returns a string representation of the recipe details.
        /// </summary>
        /// <returns>Recipe details including name, serving size, ingredients, steps, and total calories.</returns>
        public string GetRecipeDetails()
        {
            var details = new StringBuilder();
            details.AppendLine($"Recipe: {Name}");
            details.AppendLine($"Serving Size: {ServingSize}");
            details.AppendLine("Ingredients");

            foreach (var ingredient in _ingredients)
            {
                details.AppendLine($" - {ingredient.Amount} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }
            if (_steps.Count > 0)
            {
                details.AppendLine("Steps: ");
                for (int i = 0; i < _steps.Count; i++)
                {
                    details.AppendLine($" - Step {i + 1}: {_steps[i]}");
                }
            }
            else
            {
                details.AppendLine("No steps provided.");
            }

            double totalCalories = _ingredients.Sum(ingredient => ingredient.Calories);
            details.AppendLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)
            {
                details.AppendLine("!! Total calories exceed 300 !!!");
            }
            return details.ToString();
        }

        /// <summary>
        /// Event handler for property change notifications.
        /// </summary>
        /// <param name="propertyName">Name of the property that changed.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    /// <summary>
    /// Represents an ingredient with its name, calories, unit, amount, and food group.
    /// </summary>
    public class Ingredient
    {
        public string Name { get; set; } // Name of the ingredient
        public double Calories { get; set; } // Calories per unit
        public string Unit { get; set; } // Unit of measurement
        public double Amount { get; set; } // Amount of the ingredient
        public string FoodGroup { get; set; } // Food group to which the ingredient belongs
    }
}
