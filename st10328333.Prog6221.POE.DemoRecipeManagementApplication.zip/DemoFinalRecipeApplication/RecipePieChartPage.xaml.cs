﻿using LiveCharts;
using LiveCharts.Wpf;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoFinalRecipeApplication
{
    public partial class RecipePieChartPage : Page, INotifyPropertyChanged
    {
        public SeriesCollection MyFoodGroup { get; set; }
        private Dictionary<string, Recipes> recipes;
        private List<string> chosenRecipes = new List<string>();

        public event PropertyChangedEventHandler PropertyChanged;

        public RecipePieChartPage(Dictionary<string, Recipes> recipes)
        {
            InitializeComponent();
            this.recipes = recipes; // store the passed dictionary

            // Initialize the PieChart with an empty collection
            MyFoodGroup = new SeriesCollection();
            DataContext = this;
        }

        // Event handler for the Page Loaded event
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (string recipeName in recipes.Keys)
            {
                cmbRecipeName.Items.Add(recipeName);
            }
        }

        // Event handler for the "Add to Menu" button
        private void btnAddToMenu_Click(object sender, RoutedEventArgs e)
        {
            listMenuRecipe.Items.Clear();
            string selectedRecipe = cmbRecipeName.SelectedItem?.ToString();

            if (selectedRecipe != null && recipes.ContainsKey(selectedRecipe))
            {
                if (!chosenRecipes.Contains(selectedRecipe))
                {
                    chosenRecipes.Add(selectedRecipe);
                }

                // Display the selected recipes in the list
                foreach (string item in chosenRecipes)
                {
                    Recipes recipe = recipes[item];
                    listMenuRecipe.Items.Add(recipe.GetRecipeDetails());
                }
            }
            else
            {
                MessageBox.Show("Invalid recipe name. Please check the spelling of the recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Event handler for the "Create Pie Chart" button
        private void btnCreatePieChart_Click(object sender, RoutedEventArgs e)
        {
            GeneratePieChart();
        }

        // Method to generate the PieChart based on chosen recipes
        private void GeneratePieChart()
        {
            // Initialize food group totals in a dictionary
            Dictionary<string, int> foodGroupCounts = new Dictionary<string, int>
            {
                {"Fruit", 0}, {"Vegetable", 0}, {"Grains", 0}, {"Proteins", 0},
                {"Dairy", 0}, {"Fats and Oils", 0}, {"Sugar and Sweets", 0}, {"Others", 0}
            };

            // Count each food group
            foreach (string recipeName in chosenRecipes)
            {
                Recipes recipe = recipes[recipeName];

                foreach (Ingredient ingredient in recipe.Ingredients)
                {
                    string foodGroup = ingredient.FoodGroup;

                    if (foodGroupCounts.ContainsKey(foodGroup))
                    {
                        foodGroupCounts[foodGroup]++;
                    }
                }
            }

            // Sum of all food groups
            int totalIngredients = foodGroupCounts.Values.Sum();

            // Create the PieSeries for each food group
            MyFoodGroup.Clear();

            foreach (string foodGroup in foodGroupCounts.Keys)
            {
                if (foodGroupCounts[foodGroup] > 0)
                {
                    MyFoodGroup.Add(new PieSeries
                    {
                        Title = foodGroup,
                        Values = new ChartValues<int> { foodGroupCounts[foodGroup] },
                        DataLabels = true,
                        LabelPoint = chartPoint =>
                        {
                            double percentage = (chartPoint.Y / (double)totalIngredients) * 100;
                            return $"{chartPoint.Y} ({percentage:0.00}%)";
                        }
                    });
                }
            }
        }
    }
}
