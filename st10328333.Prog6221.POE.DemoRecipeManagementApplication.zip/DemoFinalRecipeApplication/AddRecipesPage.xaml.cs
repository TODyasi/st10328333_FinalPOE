﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace DemoFinalRecipeApplication
{
    /// <summary>
    /// Interaction logic for AddRecipesPage.xaml
    /// </summary>
    public partial class AddRecipesPage : Page
    {
        private Recipes newRecipe; // Variable to hold the new recipe being created

        public AddRecipesPage(ObservableCollection<Recipes> recipes)
        {
            InitializeComponent();

            // Initialize a new recipe object with default values
            newRecipe = new Recipes { Name = "New recipe", ServingSize = 1 };

            // Set the data context of the page to the new recipe object
            DataContext = newRecipe;

            // Set the collection of recipes passed from the main window
            Recipe = recipes;
        }

        public ObservableCollection<Recipes> Recipe { get; set; } // Collection of recipes to store all recipes

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate and save the recipe
            if (!string.IsNullOrWhiteSpace(NameTextBox.Text) && int.TryParse(ServingSizeTextBox.Text, out int servingSize))
            {
                // Update the name and serving size of the recipe
                newRecipe.Name = NameTextBox.Text;
                newRecipe.ServingSize = servingSize;

                // Add the new recipe to the collection of recipes
                Recipe.Add(newRecipe);

                // Show success message and navigate back
                MessageBox.Show("Recipe saved successfully!");
                NavigationService.GoBack(); // Navigate back to the previous page
            }
            else
            {
                // Display error message if recipe details are not valid
                MessageBox.Show("Please enter valid recipe details.");
            }
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            // Add a new ingredient to the recipe
            string name = IngredientNameTextBox.Text;

            if (double.TryParse(IngredientAmountTextBox.Text, out double amount) &&
                double.TryParse(IngredientCaloriesTextBox.Text, out double calories))
            {
                // Get values for unit and food group
                string unit = IngredientUnitTextBox.Text;
                string foodGroup = IngredientFoodGroupTextBox.Text;

                // Call method to add ingredient to the recipe object
                newRecipe.AddIngredient(name, amount, unit, calories, foodGroup);

                // Update the list box displaying ingredients
                IngredientsListBox.ItemsSource = null; // Clear previous items source
                IngredientsListBox.ItemsSource = newRecipe.Ingredients; // Set updated list of ingredients

                ClearIngredientFields(); // Clear input fields for ingredients
            }
            else
            {
                // Display error message if input values are not valid
                MessageBox.Show("Please enter valid numeric values for amount and calories");
            }
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            // Add a new step to the recipe
            if (!string.IsNullOrWhiteSpace(StepTextBox.Text))
            {
                // Call method to add step to the recipe object
                newRecipe.AddStep(StepTextBox.Text);

                // Update the list box displaying steps
                StepsListBox.ItemsSource = null; // Clear previous items source
                StepsListBox.ItemsSource = newRecipe.Steps; // Set updated list of steps

                StepTextBox.Clear(); // Clear input field for step description
            }
            else
            {
                // Display error message if step description is empty
                MessageBox.Show("Please enter a step description");
            }
        }

        private void ClearIngredientFields()
        {
            // Clear all input fields related to ingredients
            IngredientNameTextBox.Clear();
            IngredientAmountTextBox.Clear();
            IngredientUnitTextBox.Clear();
            IngredientCaloriesTextBox.Clear();
            IngredientFoodGroupTextBox.Clear();
        }
    }
}
