﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoFinalRecipeApplication
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public ObservableCollection<Recipes> Recipes { get; set; } // Collection of recipes displayed on the main page
        public Recipes SelectedRecipe { get; set; } // Currently selected recipe

        public MainPage()
        {
            InitializeComponent();

            // Initialize the collection of recipes and set the DataContext to this page
            Recipes = new ObservableCollection<Recipes>();
            DataContext = this;

            // Load sample data to populate the initial list of recipes
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            // Create a sample recipe and add ingredients and steps
            var sampleRecipe = new Recipes
            {
                Name = "Sample Recipe",
                ServingSize = 2
            };
            sampleRecipe.AddIngredient("Flour", 2, "cups", 200, "Grain");
            sampleRecipe.AddStep("Mix ingredients.");
            sampleRecipe.AddStep("Bake at 350 degrees for 30 minutes.");

            // Add the sample recipe to the collection of recipes
            Recipes.Add(sampleRecipe);

            // Sort recipes alphabetically
            SortRecipes();
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the page for adding a new recipe, passing the current collection of recipes
            NavigationService.Navigate(new AddRecipesPage(Recipes));
        }

        private void EditRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the page for editing the selected recipe
            if (SelectedRecipe != null)
            {
                NavigationService.Navigate(new EditRecipePage(SelectedRecipe));
            }
            else
            {
                MessageBox.Show("Please select a recipe to edit");
            }
        }

        private void DeleteRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Delete the selected recipe from the collection
            if (SelectedRecipe != null)
            {
                Recipes.Remove(SelectedRecipe);
                SelectedRecipe = null;
            }
            else
            {
                MessageBox.Show("Please select a recipe to delete.");
            }
        }

        private void RecipesListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Update selected recipe and display recipe details when selection changes
            SelectedRecipe = (Recipes)RecipesListBox.SelectedItem;

            if (SelectedRecipe != null)
            {
                RecipeDetailsTextBox.Text = SelectedRecipe.GetRecipeDetails();
                TotalCaloriesTextBlock.Text = $"Total Calories: {SelectedRecipe.TotalCalories}";
            }
            else
            {
                RecipeDetailsTextBox.Clear();
                TotalCaloriesTextBlock.Text = string.Empty;
            }
        }

        private void SortRecipes()
        {
            // Sort recipes alphabetically by name
            var sortedRecipes = new ObservableCollection<Recipes>(Recipes.OrderBy(r => r.Name));
            Recipes.Clear();

            foreach (var recipe in sortedRecipes)
            {
                Recipes.Add(recipe);
            }
        }

        private void ViewPieChartButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the page displaying a pie chart of recipes
            NavigationService.Navigate(new RecipePieChartPage(GetRecipesDictionary()));
        }

        private Dictionary<string, Recipes> GetRecipesDictionary()
        {
            // Create a dictionary of recipe names mapped to recipe objects
            var recipesDictionary = new Dictionary<string, Recipes>();
            foreach (var recipe in Recipes)
            {
                recipesDictionary.Add(recipe.Name, recipe);
            }
            return recipesDictionary;
        }
    }
}
